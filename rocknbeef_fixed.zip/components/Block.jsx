import Image from "next/image";

export default function Block({ background, title, description, linkText, linkUrl }) {
  return (
    <section className="section">
      {background && (
        <Image
          src={background}
          alt={title || "tło"}
          fill
          priority={false}
          className="object-cover"
        />
      )}
      <div className="section-inner">
        {title && <h2 className="text-3xl md:text-5xl font-extrabold mb-4">{title}</h2>}
        {description && <p className="text-lg md:text-xl text-white/90">{description}</p>}
        {linkText && linkUrl && (
          <a className="btn" href={linkUrl} target={linkUrl.startsWith("http") ? "_blank" : "_self"} rel="noreferrer">
            {linkText}
          </a>
        )}
      </div>
    </section>
  );
}