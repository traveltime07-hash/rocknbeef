import { useState } from "react";
import Image from "next/image";

export default function Gallery({ items=[] }) {
  const [active, setActive] = useState(null);
  return (
    <section className="py-12 bg-black">
      <div className="max-w-6xl mx-auto px-6">
        <h3 className="text-2xl md:text-3xl font-bold mb-6">Galeria</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {items.map((g) => (
            <button key={g.id} onClick={() => setActive(g)} className="relative aspect-square overflow-hidden rounded-xl">
              <Image src={g.image_url} alt={g.caption_pl || "galeria"} fill className="object-cover hover:scale-105 transition" />
            </button>
          ))}
        </div>
      </div>
      {active && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={() => setActive(null)}>
          <div className="relative w-full max-w-4xl aspect-video">
            <Image src={active.image_url} alt={active.caption_pl || "podgląd"} fill className="object-contain" />
          </div>
        </div>
      )}
    </section>
  );
}