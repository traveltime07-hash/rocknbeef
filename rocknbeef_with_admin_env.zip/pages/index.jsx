import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import Block from "../components/Block";
import Gallery from "../components/Gallery";
import LanguageSwitcher from "../components/LanguageSwitcher";

export default function Home() {
  const [lang, setLang] = useState("pl");
  const [blocks, setBlocks] = useState([]);
  const [translations, setTranslations] = useState({});
  const [gallery, setGallery] = useState([]);

  useEffect(() => {
    (async () => {
      const { data: b } = await supabase
        .from("blocks")
        .select("id, slug, visible, background_image, link_url, link_text, position")
        .order("position", { ascending: true });

      const { data: t } = await supabase
        .from("translations")
        .select("block_id, lang, title, description");

      const { data: g } = await supabase
        .from("gallery")
        .select("id, image_url, caption_pl, caption_en, caption_de, caption_es, position")
        .order("position", { ascending: true });

      setBlocks((b || []).filter(x => x.visible));
      const map = {};
      (t || []).forEach(row => {
        map[row.block_id] = map[row.block_id] || {};
        map[row.block_id][row.lang] = { title: row.title, description: row.description };
      });
      setTranslations(map);
      setGallery(g || []);
    })();
  }, []);

  const getTr = (id) => translations?.[id]?.[lang] || {};

  return (
    <>
      <LanguageSwitcher value={lang} onChange={setLang} />
      <header className="py-4 px-6 sticky top-0 z-40 bg-black/60 backdrop-blur">
        <div className="max-w-6xl mx-auto flex items-center gap-3">
          <div className="text-xl font-extrabold tracking-tight">Rock’nBEEF</div>
          <div className="text-white/60 text-sm">Steakhouse – Zielona Góra</div>
          <div className="flex-1" />
          <a href="/admin" className="text-white/70 hover:text-white underline">Admin</a>
        </div>
      </header>
      <main>
        {blocks.map(b => {
          const tr = getTr(b.id);
          return (
            <Block
              key={b.id}
              background={b.background_image}
              title={tr.title}
              description={tr.description}
              linkText={b.link_text}
              linkUrl={b.link_url}
            />
          );
        })}
        {blocks.some(b => b.slug === "gallery" && b.visible) && <Gallery items={gallery} />}
      </main>
      <footer className="py-8 text-center text-white/60">
        © {new Date().getFullYear()} Rock’nBEEF — Wszystkie prawa zastrzeżone
      </footer>
    </>
  );
}