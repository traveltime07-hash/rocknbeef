import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabaseClient";

const bucket = process.env.NEXT_PUBLIC_STORAGE_BUCKET || "rocknbeef";

export default function Admin() {
  const [session, setSession] = useState(null);
  const [blocks, setBlocks] = useState([]);
  const [lang, setLang] = useState("pl");
  const [translations, setTranslations] = useState({});
  const langs = ["pl","en","de","es"];
  const [msg, setMsg] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) window.location.href = "/admin/login";
      else setSession(data.session);
    });
  }, []);

  useEffect(() => {
    if (!session) return;
    (async () => {
      const { data: b } = await supabase.from("blocks").select("*").order("position", { ascending: true });
      const { data: t } = await supabase.from("translations").select("*");
      const map = {};
      (t||[]).forEach(r=>{
        map[r.block_id] = map[r.block_id]||{};
        map[r.block_id][r.lang] = { id:r.id, title:r.title, description:r.description };
      });
      setBlocks(b||[]);
      setTranslations(map);
    })();
  }, [session]);

  const saveBlock = async (block, tr) => {
    await supabase.from("blocks").update({
      background_image:block.background_image,
      link_url:block.link_url,
      link_text:block.link_text,
      visible:block.visible
    }).eq("id", block.id);
    if (tr.id) {
      await supabase.from("translations").update({ title:tr.title, description:tr.description }).eq("id", tr.id);
    } else {
      await supabase.from("translations").insert({ block_id:block.id, lang, title:tr.title, description:tr.description });
    }
  };

  const saveAll = async () => {
    for (const b of blocks) {
      const tr = translations[b.id]?.[lang]||{};
      await saveBlock(b, tr);
    }
    setMsg("✅ Zapisano zmiany");
  };

  if (!session) return null;

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="p-4 border-b border-white/10 flex items-center gap-3">
        <div className="font-bold">Admin Rock’nBEEF</div>
        <div className="flex-1" />
        {langs.map(l=>(
          <button key={l} onClick={()=>setLang(l)} className={lang===l?"bg-white text-black px-3 py-1 rounded-lg":"px-3 py-1"}>
            {l.toUpperCase()}
          </button>
        ))}
      </header>
      <main className="p-6 max-w-5xl mx-auto space-y-6">
        {msg && <div className="bg-green-700 p-3 rounded">{msg}</div>}
        {blocks.map(b=>{
          const tr = translations[b.id]?.[lang]||{};
          return (
            <div key={b.id} className="bg-white/5 p-4 rounded-xl">
              <div className="mb-2 font-bold">{b.slug}</div>
              <input className="w-full mb-2 px-2 py-1 bg-white/10" placeholder="Tytuł" value={tr.title||""} onChange={e=>setTranslations(prev=>({
                ...prev, [b.id]:{...prev[b.id],[lang]:{...tr,title:e.target.value}}
              }))} />
              <textarea className="w-full mb-2 px-2 py-1 bg-white/10" placeholder="Opis" value={tr.description||""} onChange={e=>setTranslations(prev=>({
                ...prev, [b.id]:{...prev[b.id],[lang]:{...tr,description:e.target.value}}
              }))}></textarea>
              <input className="w-full mb-2 px-2 py-1 bg-white/10" placeholder="Link URL" value={b.link_url||""} onChange={e=>setBlocks(prev=>prev.map(x=>x.id===b.id?{...x,link_url:e.target.value}:x))} />
              <input className="w-full mb-2 px-2 py-1 bg-white/10" placeholder="Link tekst" value={b.link_text||""} onChange={e=>setBlocks(prev=>prev.map(x=>x.id===b.id?{...x,link_text:e.target.value}:x))} />
              <label className="flex items-center gap-2">
                <input type="checkbox" checked={b.visible} onChange={e=>setBlocks(prev=>prev.map(x=>x.id===b.id?{...x,visible:e.target.checked}:x))} />
                Widoczny
              </label>
            </div>
          );
        })}
        <button onClick={saveAll} className="px-5 py-2 rounded-lg bg-white text-black font-bold">Zapisz</button>
      </main>
    </div>
  );
}